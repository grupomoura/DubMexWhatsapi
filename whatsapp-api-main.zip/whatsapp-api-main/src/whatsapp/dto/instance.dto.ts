export class InstanceDto {
  instanceName: string;
}
