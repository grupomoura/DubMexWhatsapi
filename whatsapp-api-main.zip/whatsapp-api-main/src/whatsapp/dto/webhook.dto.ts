export class WebhookDto {
  enabled?: boolean;
  url?: string;
}
